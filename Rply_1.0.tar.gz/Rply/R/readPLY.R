readPLY<-function(filename, verbose=T)
{
    return (cpp_readPLY(filename,verbose));
}
